package User;

public interface KidProfile extends Profile {
    int getAgeRating();
}
