package User;

public interface StandardProfile extends Profile {
}
