package User;

public class StandardProfileClass extends AbsProfile implements StandardProfile {
    public StandardProfileClass(String name){
        super(name);
    }
}
