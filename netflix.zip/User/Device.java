package User;

public interface Device {

    String getName();


}
