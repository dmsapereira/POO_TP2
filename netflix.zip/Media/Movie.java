package Media;

public interface Movie extends Media {
    int getDuration();
}
