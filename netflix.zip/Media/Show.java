package Media;

public interface Show extends Media {

    int getNumSeasons();

    int getNumEpisodes();
}
