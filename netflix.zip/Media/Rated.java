package Media;

public interface Rated extends Media {

    float getRating();

    void addRating(int rating);


}
