package Exceptions;

public class MediaIterationException extends Exception {
    public MediaIterationException(){super();}

    public String toString(){ return "No show found.";}

}
