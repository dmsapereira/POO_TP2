package Exceptions;

public class AgeRatingMismatchException extends Exception {
    public AgeRatingMismatchException(){
        super();
    }

    public String toString(){
        return "Show not available.";
    }
}
